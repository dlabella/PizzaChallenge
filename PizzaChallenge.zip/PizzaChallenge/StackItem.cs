﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaChallenge
{
    public class StackItem
    {
        public PizzaCell StartCell { get;set;}
        public List<PizzaSlice> Slices { get;set;}
        public StackItem()
        {
            Slices=new List<PizzaSlice>();
        }
        public StackItem(PizzaCell startCell, List<PizzaSlice> slices)
        {
            StartCell = startCell;
            Slices = slices;
        }
    }
}
